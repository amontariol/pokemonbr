<?php
session_start();
require_once('../Vue/wiki.php');
?>