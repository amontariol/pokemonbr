<?php
session_start();
header('location:../Vue/home.php')
?>