<?php
    //Fichier permettant l'acces à la db
    define('HOSTNAME', 'localhost');
    define('DBNAME', 'mydb');
    define('USERNAME', 'root');
    define('PASSWORD', '');
?>